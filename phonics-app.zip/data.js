// Example generated-style data.
// Replace this file by running:
//     ./generate_data.py cards.json
//
// The image files referenced here are expected to live in images/.

const cardSets = {
  cvc: {
    name: "CVC Words",
    cards: [
      { word: "cat", rendering: "a", image: "images/cat.png" },
      { word: "pig", rendering: "i", image: "images/pig.png" },
      { word: "dog", rendering: "o", image: "images/dog.png" },
      { word: "sun", rendering: "u", image: "images/sun.png" }
    ]
  },

  cvcc: {
    name: "CVCC Words",
    cards: [
      { word: "hand", rendering: "nd", image: "images/hand.png" },
      { word: "lamp", rendering: "mp", image: "images/lamp.png" },
      { word: "nest", rendering: "st", image: "images/nest.png" }
    ]
  }
};
